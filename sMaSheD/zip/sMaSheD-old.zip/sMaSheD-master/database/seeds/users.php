<?php

return [
    [
        'name' => 'smashed',
        'email' => 'smashed@example.com',
        'password' => Hash::make('somewhat_smashed_pass'),
    ],
];
